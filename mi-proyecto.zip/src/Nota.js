import React from 'react';

const Nota = ({ id, titulo, descripcion, importante, eliminarNota }) => {
  return (
    <div className={`nota ${importante ? 'importante' : ''}`}>
      {titulo && <h3>{titulo}</h3>}
      <p>{descripcion}</p>
      <button onClick={() => eliminarNota(id)}>Eliminar</button>
    </div>
  );
};

export default Nota;
