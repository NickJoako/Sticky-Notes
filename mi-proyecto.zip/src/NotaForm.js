import React, { useState } from 'react';

const NotaForm = ({ addNota }) => {
  const [titulo, setTitulo] = useState('');
  const [descripcion, setDescripcion] = useState('');
  const [importante, setImportante] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (descripcion.trim() === '') {
      alert('La descripción es obligatoria.');
      return;
    }
    addNota(titulo, descripcion, importante);
    setTitulo('');
    setDescripcion('');
    setImportante(false);
  };

  return (
    <form onSubmit={handleSubmit} className="note-form m-3">
      <input
        type="text"
        placeholder="Título (opcional)"
        value={titulo}
        onChange={(e) => setTitulo(e.target.value)}
      />
      <textarea
        placeholder="Descripción *"
        value={descripcion}
        onChange={(e) => setDescripcion(e.target.value)}
        required
      />
      <label>
        <input
          type="checkbox"
          checked={importante}
          onChange={(e) => setImportante(e.target.checked)}
        />{' '}
        Importante
      </label>
      <button className='m-3' type="submit">Agregar Nota</button>
    </form>
  );
};

export default NotaForm;
