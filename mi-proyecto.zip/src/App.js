import React, { useState, useEffect } from 'react';
import './App.css';
import NotaForm from './NotaForm';
import Nota from './Nota';

const App = () => {
  const [notas, setNotas] = useState([]);

  useEffect(() => {
    const storedNotas = JSON.parse(localStorage.getItem('stickyNotes')) || [];
    setNotas(storedNotas);
  }, []);

  useEffect(() => {
    localStorage.setItem('stickyNotes', JSON.stringify(notas));
  }, [notas]);

  const addNota = (titulo, descripcion, importante) => {
    const nuevaNota = {
      id: Date.now(),
      titulo: titulo || '',
      descripcion,
      importante
    };
    setNotas([...notas, nuevaNota]);
  };

  const eliminarNota = (id) => {
    const actualizarNotas = notas.filter(nota => nota.id !== id);
    setNotas(actualizarNotas);
  };

  return (  
    <div className="app">
      <h1 className='text-center my-3'>Sticky Notes</h1>
      <NotaForm addNota={addNota} />
      <div className="notas-container">
        {notas.map(nota => (
          <Nota
            key={nota.id}
            id={nota.id}
            titulo={nota.titulo}
            descripcion={nota.descripcion}
            importante={nota.importante}
            eliminarNota={eliminarNota}
          />
        ))}
      </div>
    </div>
  );
};

export default App;
